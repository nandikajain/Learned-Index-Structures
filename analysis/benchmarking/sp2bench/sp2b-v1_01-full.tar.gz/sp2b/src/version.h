//
// Version declaration 
//
// Author: Michael Schmidt, Christoph Pinkel <>, (C) 2007-2008
// Copyright: See COPYING file that comes with this distribution
//
#ifndef VERSION_H
#define VERSION_H

#define VERSION_NUMBER "1.01"

#endif // VERSION_H
