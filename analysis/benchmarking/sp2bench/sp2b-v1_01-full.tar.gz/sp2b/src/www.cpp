//
// C++ Implementation: Www 
//
// Author: Michael Schmidt, Christoph Pinkel <>, (C) 2007-2008
// Copyright: See COPYING file that comes with this distribution
//
#include "www.h"

Www::Www(unsigned num, unsigned year)
    : Document(DOCTYPE_WWW, num, year)
{
}

Www::~Www()
{
}
